package com.linkhub.linkservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
