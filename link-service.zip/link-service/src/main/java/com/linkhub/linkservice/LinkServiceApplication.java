package com.linkhub.linkservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinkServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinkServiceApplication.class, args);
	}

}
